To Install DrEncoder locally:
Create a DrEncoder folder somewhere.
Move the DrEncoder.zip file into that folder and decompress all files within it into the DrEncoder.
Open the DrEncoder folder in Explorer and double click on DrEncoder.html
This should be usable from your browser without even having a web server.
You may see a warning from your browser telling you it could harm your computer - this is because this is a local file.  Ignore the warning.
Party on!
See the .mp4 file for detailed instructions on how to use DrEnocder.
